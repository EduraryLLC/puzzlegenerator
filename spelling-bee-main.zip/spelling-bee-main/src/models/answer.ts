export interface Answer {
  answers: Array<string>;
  availableLetters: string;
  middleLetter: string;
}
