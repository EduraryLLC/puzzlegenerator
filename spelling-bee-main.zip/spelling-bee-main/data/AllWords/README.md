# Removed words
As pointed out by a user, the original word list https://github.com/en-wl/wordlist/blob/master/alt12dicts/2of4brif.txt
contains slurs! Turns out a lot of them!

I manually compiled wordsRemoved.txt by looking at https://en.wikipedia.org/wiki/List_of_ethnic_slurs
It is possible I still missed some, so if you see some please contact me and I'll remove them too.

# Added words
Users (including myself) often find gaps in the wordlist, or words they feel are common enough they should be included but aren't.
In these cases they should be added to `wordsAdded.txt`

Why not just edit the original word list?
I want to keep the original wor list unchanged so if it changes upstream I can pull it without having to re-apply all my changes too.