<script setup lang="ts">
import Support from "./Support.vue";
</script>

<template>
  <h2>You're a spelling Genius!</h2>
  <Support />
  <span
    >If you liked this game, you might like the Irish version:
    <el-link
      type="primary"
      href="https://beach-litriochta.netlify.app"
      target="_blank">
      beacha litríochta
    </el-link>
  </span>
</template>
