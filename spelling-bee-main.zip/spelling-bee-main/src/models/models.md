this is not for database models, just typescript definitions.
