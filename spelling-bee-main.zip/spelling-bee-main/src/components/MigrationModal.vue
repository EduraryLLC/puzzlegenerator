<template>
  <div>
    <p>
      The
      <a href="https://spelling-b.netlify.app"
        >https://spelling-b.netlify.app</a
      >
      URL will stop working soon.
    </p>
    <p>
      Please use
      <a href="https://spelling-bee-free.pages.dev"
        >https://spelling-bee-free.pages.dev</a
      >
      instead. Sorry for the short notice!
    </p>
  </div>
</template>
